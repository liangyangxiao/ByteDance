//
//  group_prize.hpp
//  ByteDancePractices
//
//  Created by 梁杨晓 on 2019/4/24.
//  Copyright © 2019年 梁杨晓. All rights reserved.
//

#ifndef group_prize_hpp
#define group_prize_hpp

#include <stdio.h>

#endif /* group_prize_hpp */
int prize_solution();
