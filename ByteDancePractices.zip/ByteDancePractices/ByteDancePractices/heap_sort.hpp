//
//  heap_sort.hpp
//  ByteDancePractices
//
//  Created by 梁杨晓 on 2019/4/29.
//  Copyright © 2019年 梁杨晓. All rights reserved.
//

#ifndef heap_sort_hpp
#define heap_sort_hpp

#include <stdio.h>

#endif /* heap_sort_hpp */

float log_2(int n);
int max_cal_3(int m1,int m2,int m3);
void swap(int& a,int& b);
void heap_sort_solution();

