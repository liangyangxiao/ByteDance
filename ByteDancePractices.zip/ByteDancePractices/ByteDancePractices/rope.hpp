//
//  rope.hpp
//  ByteDancePractices
//
//  Created by 梁杨晓 on 2019/4/25.
//  Copyright © 2019年 梁杨晓. All rights reserved.
//

#ifndef rope_hpp
#define rope_hpp

#include <stdio.h>

#endif /* rope_hpp */
void rope_solution();
