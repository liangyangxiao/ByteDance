//
//  auto_process_str.hpp
//  ByteDancePractices
//
//  Created by 梁杨晓 on 2019/4/24.
//  Copyright © 2019年 梁杨晓. All rights reserved.
//

#ifndef auto_process_str_hpp
#define auto_process_str_hpp

#include <stdio.h>
#include <string>
using namespace std;

#endif /* auto_process_str_hpp */

string auto_str(string text);
string auto_str2(string text);
