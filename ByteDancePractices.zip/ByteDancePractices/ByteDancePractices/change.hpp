//
//  change.hpp
//  ByteDancePractices
//
//  Created by 梁杨晓 on 2019/4/24.
//  Copyright © 2019年 梁杨晓. All rights reserved.
//

#ifndef change_hpp
#define change_hpp

#include <stdio.h>

#endif /* change_hpp */

void change_solution1();
void change_solution2();
